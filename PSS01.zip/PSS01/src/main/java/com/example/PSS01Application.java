package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PSS01Application {

	public static void main(String[] args) {
		SpringApplication.run(PSS01Application.class, args);
	}

}
