package com.example.domain;

import lombok.Data;

@Data
public class ContentInfo {
	
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String name;
	private String pathNo;
	private String title;
	private String keyword;
	private String description;
	private String header;
	private String main;
	private String footer;
	private String generatedUrl;
}
