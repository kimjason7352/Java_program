package com.example.persistence;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.domain.ContentInfo;
import com.example.practice.CMSUserForm;
import com.example.practice.ContentForm;

@Mapper
public interface CMSMapper {
	
	public void insert(ContentInfo contentInfo);
	public List<ContentInfo> select(ContentInfo contentInfo);
	public List<ContentInfo> selectAll();
	public void delete(ContentInfo contentInfo);
	public ContentInfo selectById(Integer id);
	public void update(ContentInfo contentInfo);
	public ContentInfo selectByPathNo(String pathNo);
	public int countCMSUser(CMSUserForm form);
	public int countContent(ContentForm form);
	public int countContent2(ContentInfo form);
	public String selectPathNo(ContentInfo form);
}
