package com.example.persistence;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.domain.NamecardInput;

@Mapper
public interface NamecardInputMapper {
	
	public void insert(NamecardInput namecardInput);
	public void update(NamecardInput namecardInput);
	public void delete(NamecardInput namecardInput);
	public List<NamecardInput> select(NamecardInput namecardInput);

}
