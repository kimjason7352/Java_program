package com.example.practice;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.example.domain.ContentInfo;
import com.example.service.CMSService;

@Controller
@SessionAttributes({"contentForm", "cmsUserForm", "contentInfo"})
public class CMSController {
	
	@Autowired
	private CMSService service;
	
	@Autowired
	private CMSUserForm cmsUserForm;
	
	@ModelAttribute(value = "contentForm")
    public ContentForm setForm() {
        return new ContentForm();
    }
	
	@ModelAttribute(value = "contentInfo")
    public ContentInfo setInfo() {
        return new ContentInfo();
    }
	
	@ModelAttribute(value = "cmsUserForm")
    public CMSUserForm setUserForm() {
        return new CMSUserForm();
    }
	
	private String generateUrl(String pathNo) {
        // ここで実際のURL生成のロジックを実装
        // 例として pathNumber を利用して URL を生成
        return "cms/content/frontpage/" + pathNo;
    }
	
	//ログイン画面へ遷移
	@RequestMapping(value = "/cmsLogin")
	public String cmsLogin() {
		return "cms/cmsLogin";
	}
	
	//一覧への無効なアクセス
	@RequestMapping(value = "/contentList")
	public String invalidContentList() {
		return "redirect:cmsLogin";
	}

	//登録への無効なアクセス
	@RequestMapping(value = "/contentRegistration")
	public String invalidContentRegistration() {
		return "redirect:cmsLogin";
	}
	
	//編集への無効なアクセス
	@RequestMapping(value = "/contentEdit")
	public String invalidContentEdit() {
		return "redirect:cmsLogin";
	}
	
	
	//ログイン画面
	@RequestMapping(value = "/contentList", params = "login_btn") 
	public String goToContentList(@Validated @ModelAttribute("cmsUserForm") CMSUserForm form
			, BindingResult result, Model model) {
		
		if(form.getUserName().equals("") || form.getPassword().equals("")) {
			result.reject("errors.lackOfInput");
		}
		
		if(!form.getUserName().equals("") && !form.getPassword().equals("") &&service.searchCMSUser(form) == 0) {
			result.reject("errors.noSuchUser");	
			
		} 
		
		if(result.hasErrors()) {
			return "cms/cmsLogin";
		}
		
		BeanUtils.copyProperties(form, cmsUserForm);
		
		return "redirect:contentList?show";
	}
	
	//一覧から登録画面への遷移
	@RequestMapping(value = "/contentRegistration", params = "registration")
	public String contentRegistration(@ModelAttribute("contentForm") ContentForm form, Model model) {
		model.addAttribute("userName", cmsUserForm.getUserName());
		return "cms/contentRegistration";
	}
	
	//コンテンツ登録実行
	@RequestMapping(value = "/contentList", params="executeRegistration")
	public String finishRegistration(@Validated @ModelAttribute("contentForm") ContentForm form
			, BindingResult result, Model model) {
		
		String pathNo = form.getPathNo();
		
		if(form.getName().equals("")) {
			result.reject("errors.emptyContentName");
		}
		
		if(pathNo.equals("")) {
			result.reject("errors.emptyPathNo");
		}
		
		//pathNOに重複がないかを確認
		if(!pathNo.equals("") && service.searchPathNo(form) == 1) {
			result.reject("errors.pathDuplication");
		}
		
		if(form.getTitle().equals("")) {
			result.reject("errors.emptyTitle");
		}
		
		if(form.getKeyword().equals("")) {
			result.reject("errors.emptyKeyword");
		}
		
		if(form.getDescription().equals("")) {
			result.reject("errors.emptyDescription");
		}
		
		if(form.getHeader().equals("")) {
			result.reject("errors.emptyHeader");
		}
		
		if(form.getMain().equals("")) {
			result.reject("errors.emptyMain");
		}
		
		if(form.getFooter().equals("")) {
			result.reject("errors.emptyFooter");
		}
		
		if(result.hasErrors()) {
			model.addAttribute("userName", cmsUserForm.getUserName());
            return "cms/contentRegistration";
        }
		
		ContentInfo contentInfo = new ContentInfo();
		BeanUtils.copyProperties(form, contentInfo);
		service.insertContentInfo(contentInfo);
		
		return "redirect:contentList?show";
	}
	
	//コンテンツ一覧表示
	@RequestMapping(value = "/contentList", params = "show")
	public String contentList(@ModelAttribute("contentInfo") ContentInfo form, Model model) {
		List<ContentInfo> list = service.contentInfo(form);
        model.addAttribute("contentList", list);
        model.addAttribute("userName", cmsUserForm.getUserName());
		return "cms/contentList";
	}
	
	
	//リストから削除
	@RequestMapping(value = "/contentRegistration", params="remove")
	public String remove(@ModelAttribute("contentInfo") ContentInfo form, Model model) {
		
		service.deleteContentInfo(form);	
		model.addAttribute("userName", cmsUserForm.getUserName());
		return "redirect:contentList?show";
	}
	
	//リストから編集画面への遷移
	@RequestMapping(value = "/contentRegistration", params="edit")
	public String editContent(@ModelAttribute("contentInfo") ContentInfo form, Model model) {
		ContentInfo contentInfo = service.getContentInfoById(form.getId());
		model.addAttribute("contentInfo", contentInfo);
		model.addAttribute("userName", cmsUserForm.getUserName());
		return "cms/contentEdit";
	}
	
	//編集画面での編集実行
	@RequestMapping(value = "/contentList", params="edit")
	public String executeEdit(@Validated @ModelAttribute("contentInfo") ContentInfo form, BindingResult result, Model model) {
		
		
		
		if(form.getName().equals("")) {
			result.reject("errors.emptyContentName");
		}
		
		if(form.getPathNo().equals("")) {
			result.reject("errors.emptyPathNo");
		}
		
		//pathNOに重複がないかを確認
		if(service.searchPathNo2(form) == 1) {
			result.reject("errors.pathDuplication");
		}
		
		if(form.getTitle().equals("")) {
			result.reject("errors.emptyTitle");
		}
		
		if(form.getKeyword().equals("")) {
			result.reject("errors.emptyKeyword");
		}
		
		if(form.getDescription().equals("")) {
			result.reject("errors.emptyDescription");
		}
		
		if(form.getHeader().equals("")) {
			result.reject("errors.emptyHeader");
		}
		
		if(form.getMain().equals("")) {
			result.reject("errors.emptyMain");
		}
		
		if(form.getFooter().equals("")) {
			result.reject("errors.emptyFooter");
		}
		
		if(result.hasErrors()) {
			model.addAttribute("userName", cmsUserForm.getUserName());
            return "cms/contentEdit";
        }
		
		
		service.updateContentInfo(form);
		
		return "redirect:contentList?show";
	}
	
	//ヘッダー
	
	//一覧画面から一覧画面への自画面遷移
	@RequestMapping(value = "/contentRegistration", params="cmsList")
	public String listToList() {
		return "redirect:contentList?show";
	}

	@RequestMapping(value = "/contentList", params="cmsRegistration")
	public String registrationToRegistration(Model model) {
		model.addAttribute("userName", cmsUserForm.getUserName());
		return "cms/contentRegistration";
	}

	@RequestMapping(value = "/contentList", params="cmsList")
	public String registrationToList() {
		return "redirect:contentList?show";
	}
	
	@GetMapping("/cms/content/frontpage/{pathNo}")
	public String showFrontPageForPath(@PathVariable String pathNo, Model model) {
	    // ContentInfoを取得
	    ContentInfo contentInfo = service.getContentInfoByPathNo(pathNo);

	    // URLを生成
	    String generatedUrl = generateUrl(pathNo);
	    contentInfo.setGeneratedUrl(generatedUrl);

	    model.addAttribute("contentInfo", contentInfo);
	    return "cms/frontPage";
	}
	
	//ログアウト
	@RequestMapping(value = "/contentRegistration", params = "logout")
	public String ListToLogout(SessionStatus sessionStatus) {
		sessionStatus.setComplete();
		return "redirect:cmsLogin";
	}
	
	@RequestMapping(value = "/contentList", params = "logout")
	public String RegistrationEditToLogout(SessionStatus sessionStatus) {
		sessionStatus.setComplete();
		return "redirect:cmsLogin";
	}
	
	//もどる
	@RequestMapping(value = "/contentRegistration", params = "return")
	public String returnLogout(SessionStatus sessionStatus) {
		sessionStatus.setComplete();
		return "redirect:cmsLogin";
	}

	@RequestMapping(value = "/contentList", params = "return")
	public String ListToLogout(Model model) {
		model.addAttribute("userName", cmsUserForm.getUserName());
		return "redirect:contentList?show";
	}
}
