package com.example.practice;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class CMSUserForm {
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;

}
