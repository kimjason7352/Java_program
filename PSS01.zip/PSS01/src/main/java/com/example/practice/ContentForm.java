package com.example.practice;

import lombok.Data;

@Data
public class ContentForm {
	
	private static final long serialVersionUID = 1L;
	private String name;
	private String pathNo;
	private String title;
	private String keyword;
	private String description;
	private String header;
	private String main;
	private String footer;
	
}
