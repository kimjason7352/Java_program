package com.example.practice;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.example.domain.NamecardInput;
import com.example.service.NamecardInputService;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

@Controller
@SessionAttributes({"namecardForm", "namecardInput"})
public class NamecardController {
	
	@Autowired
	private NamecardInputService service;
	
	
	@ModelAttribute(value = "namecardForm")
    public NamecardForm setForm() {
        return new NamecardForm();
    }
	
	@ModelAttribute(value = "namecardInput")
    public NamecardInput form() {
        return new NamecardInput();
    }
	
	private List<NamecardInput> convertCsvDataToNamecardInputList(List<String[]> csvData) {
	    List<NamecardInput> namecardInputs = new ArrayList<>();

	    for (String[] row : csvData) {
	        // CSVデータからNamecardInputオブジェクトを作成
	        NamecardInput namecardInput = new NamecardInput();
	        namecardInput.setFirstnameCh(row[0]); // firstnameCh
	        namecardInput.setLastnameCh(row[1]);  // lastnameCh
	        namecardInput.setFirstnameKana(row[2]);  // firstnameKana
	        namecardInput.setLastnameKana(row[3]);  // lastnameKana
	        namecardInput.setCompany(row[4]);  // company
	        namecardInput.setPhone(row[5]);  // phone
	        namecardInput.setMail(row[6]);  // mail

	        // その他のフィールドについても同様にセット

	        // リストに追加
	        namecardInputs.add(namecardInput);
	    }

	    return namecardInputs;
	}
	
	private List<NamecardInput> readCsvFile(String filePath) {
		try (CSVReader csvReader = new CSVReader(new InputStreamReader(new FileInputStream(filePath), StandardCharsets.UTF_8))) {
	        List<String[]> csvData = csvReader.readAll();
	        List<NamecardInput> namecards = convertCsvDataToNamecardInputList(csvData);
	        return namecards;
	    } catch (IOException | CsvException e) {
	        e.printStackTrace();
	        // エラーが発生した場合は適切に処理してください
	        return null;
	    }
    }
	
	public static void exportNamecardsToCSV(List<NamecardInput> namecards, String outputPath) {
        try (CSVWriter csvWriter = new CSVWriter(new OutputStreamWriter(new FileOutputStream(outputPath), StandardCharsets.UTF_8))) {

            // CSVヘッダーを書き込む
            String[] header = {
            		"id"
            		, "firstnameCh"
            		, "lastnameCh"
            		,"firstnameKana"
            		, "lastnameKana"
            		, "company"
            		, "phone"
            		, "mail"};
            csvWriter.writeNext(header);

            // データを書き込む
            for (NamecardInput namecard : namecards) {
                String[] rowData = {
                        String.valueOf(namecard.getId()),
                        namecard.getFirstnameCh(),
                        namecard.getLastnameCh(),
                        namecard.getFirstnameKana(),
                        namecard.getLastnameKana(),
                        namecard.getCompany(),
                        namecard.getPhone(),
                        namecard.getMail(),
                };
                csvWriter.writeNext(rowData);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	
	
	@RequestMapping(value = "/namecardList")
	public String goToList(@ModelAttribute("namecardInput") NamecardInput form, Model model, SessionStatus sessionStatus) {
		sessionStatus.setComplete();
		List<NamecardInput> list = service.namecardInput(form);
        model.addAttribute("namecardInputList", list);
		return "namecard/namecardList";
	}
	
	@RequestMapping(value = "/namecardInput", params="registration")
	public String toInputr() {
		return "namecard/namecardInput";
	}
	
	@RequestMapping(value = "/namecardInput", params="read")
	public String readCsv() {
		
		String csvFilePath = "C:\\TEMP\\test\\addnamecards.csv";
        List<NamecardInput> namecards = readCsvFile(csvFilePath);

        // CSVから読み込んだデータをデータベースに挿入
        for (NamecardInput namecard : namecards) {
            service.insertNamecardInput(namecard);
        }
		
		
		return "redirect:namecardList";
	}
	
	@RequestMapping(value = "/namecardInput", params="output")
	public String outputCSV(String[] args, @ModelAttribute("namecardInput") NamecardInput form, Model model) {
		
		
		List<NamecardInput> namecards = service.namecardInput(form);
		String outputPath = "C:\\TEMP\\test\\namecards.csv";
		exportNamecardsToCSV(namecards, outputPath);
		
		return "redirect:namecardList";
	}
	
	
	@RequestMapping(value = "/namecardInput", params="edit")
	public String edit(@ModelAttribute("namecardInput") NamecardInput form, Model model) {
		model.addAttribute("namecardInput", form);	
		return "namecard/namecardEdit";
	}
	
	@RequestMapping(value = "/namecardList", params="return_to_list")
	public String returnToList() {
		
		return "redirect:namecardList";
	}
	
	@RequestMapping(value = "/namecardList", params="execute")
	public String executeEdit(@Validated @ModelAttribute("namecardInput") NamecardInput form, BindingResult result, 
			Model model) {
		

		if(form.getFirstnameCh().equals("")||form.getLastnameCh().equals("")||form.getFirstnameKana().equals("")||form.getLastnameKana().equals("")) {
			result.reject("errors.emptyName");
		}
		if(form.getCompany().equals("")) {
			result.reject("errors.emptyCompany");
		}
		if(form.getPhone().equals("")) {
			result.reject("errors.emptyPhone");
		}
		if(form.getMail().equals("")) {
			result.reject("errors.emptyMail");
		}
		
		if((!form.getFirstnameCh().equals("")||form.getLastnameCh().equals("")||form.getFirstnameKana().equals("")||form.getLastnameKana().equals(""))&&
				(!form.getFirstnameCh().matches("^[一-龠]*$") ||!form.getLastnameCh().matches("^[一-龠]*$"))){
			result.reject("errors.invalidNameCh");
		}
		
		if((!form.getFirstnameCh().equals("")||form.getLastnameCh().equals("")||form.getFirstnameKana().equals("")||form.getLastnameKana().equals(""))&&
				(!form.getFirstnameKana().matches("^[ァ-ヶー]*$") ||!form.getLastnameKana().matches("^[ァ-ヶー]*$"))){
			result.reject("errors.invalidNameKana");
		}
		
		if(!form.getPhone().equals("")&&!form.getPhone().matches("^0\\d{9,10}$")){
			result.reject("errors.invalidPhone");
		}
		
		if(!form.getMail().equals("")&&
			!form.getMail().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")){
			result.reject("errors.invalidMail");
		}
		
		if(result.hasErrors()) {
            return "namecard/namecardEdit";
        }
		
		//NamecardInput namecardInput = new NamecardInput();
		//BeanUtils.copyProperties(form, namecardInput);
		//service.updateNamecardInput(namecardInput);
		service.updateNamecardInput(form);
		
		return "redirect:namecardList";
	}
	
	@RequestMapping(value = "/namecardInput", params="remove")
	public String remove(@ModelAttribute("namecardInput") NamecardInput form, Model model) {
		
		NamecardInput namecardInput = new NamecardInput();
		BeanUtils.copyProperties(form, namecardInput);
		service.deleteNamecardInput(namecardInput);
		
		return "redirect:namecardList";
	}
	
	@RequestMapping(value = "/namecardList", params="registration")
	public String registrationToList(@Validated @ModelAttribute("namecardForm") NamecardForm form, BindingResult result) {
		
		if(form.getFirstnameCh().equals("")||form.getLastnameCh().equals("")||form.getFirstnameKana().equals("")||form.getLastnameKana().equals("")) {
			result.reject("errors.emptyName");
		}
		if(form.getCompany().equals("")) {
			result.reject("errors.emptyCompany");
		}
		if(form.getPhone().equals("")) {
			result.reject("errors.emptyPhone");
		}
		if(form.getMail().equals("")) {
			result.reject("errors.emptyMail");
		}
		
		if((!form.getFirstnameCh().equals("")||form.getLastnameCh().equals("")||form.getFirstnameKana().equals("")||form.getLastnameKana().equals(""))&&
				(!form.getFirstnameCh().matches("^[一-龠]*$") ||!form.getLastnameCh().matches("^[一-龠]*$"))){
			result.reject("errors.invalidNameCh");
		}
		
		if((!form.getFirstnameCh().equals("")||form.getLastnameCh().equals("")||form.getFirstnameKana().equals("")||form.getLastnameKana().equals(""))&&
				(!form.getFirstnameKana().matches("^[ァ-ヶー]*$") ||!form.getLastnameKana().matches("^[ァ-ヶー]*$"))){
			result.reject("errors.invalidNameKana");
		}
		
		if(!form.getPhone().equals("")&&!form.getPhone().matches("^0\\d{9,10}$")){
			result.reject("errors.invalidPhone");
		}
		
		if(!form.getMail().equals("")&&
			!form.getMail().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")){
			result.reject("errors.invalidMail");
		}
		
		if(result.hasErrors()) {
            return "namecard/namecardInput";
        }
		
		
		NamecardInput namecardInput = new NamecardInput();
		BeanUtils.copyProperties(form, namecardInput);
		service.insertNamecardInput(namecardInput);
		
		
		return "redirect:namecardList";
	}
}
