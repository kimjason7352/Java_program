package com.example.practice;

import lombok.Data;

@Data
public class NamecardForm {
	private static final long serialVersionUID = 1L;
	private String firstnameCh;
	private String lastnameCh;
	private String firstnameKana;
	private String lastnameKana;
	private String company;
	private String phone;
	private String mail;
	
}
