package com.example.practice;

import java.io.Serializable;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import lombok.Data;

@Data
@Component
@SessionScope
public class UserForm implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String userID;
	private String password;
	private String passwordConf;

}
