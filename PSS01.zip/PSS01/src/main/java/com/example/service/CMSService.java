package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.ContentInfo;
import com.example.persistence.CMSMapper;
import com.example.practice.CMSUserForm;
import com.example.practice.ContentForm;

@Service
public class CMSService {
	
	@Autowired
	private CMSMapper mapper;
	
	public void insertContentInfo(ContentInfo contentInfo) {
		mapper.insert(contentInfo);
	}
	
	public List<ContentInfo> contentInfo(ContentInfo contentInfo) {
        List<ContentInfo> list = mapper.select(contentInfo);
        return list;
    }
	
	public List<ContentInfo> getAllContentInfo() {
        return mapper.selectAll(); // CMSMapperに対応するselectAllメソッドがあると仮定
    }
	
	public void deleteContentInfo(ContentInfo contentInfo) {
		mapper.delete(contentInfo);
	}
	
	public ContentInfo getContentInfoById(Integer id) {
		return mapper.selectById(id);
	}
	
	public void updateContentInfo(ContentInfo contentInfo) {
		mapper.update(contentInfo);
	}
	
	public ContentInfo getContentInfoByPathNo(String pathNo) {
	    return mapper.selectByPathNo(pathNo);
	}
	
	public int searchCMSUser(CMSUserForm form) {
		int countCMSUser = mapper.countCMSUser(form);
		return countCMSUser;
	}
	
	public int searchPathNo(ContentForm form) {
		int countContent = mapper.countContent(form);
		return countContent;
	}
	
	public int searchPathNo2(ContentInfo form) {
		int countContent = mapper.countContent2(form);
		return countContent;
	}
	
	public String getPathNoById(ContentInfo form) {
		String pathNo = mapper.selectPathNo(form);
		return pathNo;
	}

}
