package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.domain.NamecardInput;
import com.example.persistence.NamecardInputMapper;

@Service
public class NamecardInputService {
	
	@Autowired
	private NamecardInputMapper mapper;
	
	public void insertNamecardInput(NamecardInput namecardInput) {
		mapper.insert(namecardInput);
	}
	
	public void deleteNamecardInput(NamecardInput namecardInput) {
		mapper.delete(namecardInput);
	}
	
	public void updateNamecardInput(NamecardInput namecardInput) {
		mapper.update(namecardInput);
	}
	
	public List<NamecardInput> namecardInput(NamecardInput namecardInput) {
        List<NamecardInput> list = mapper.select(namecardInput);
        return list;
    }
}
