-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2024-01-16 07:41:38
-- サーバのバージョン： 10.4.28-MariaDB
-- PHP のバージョン: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `techfun`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `cms_user`
--

CREATE TABLE `cms_user` (
  `id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_name_kana` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `company` varchar(20) NOT NULL,
  `passwd` varchar(16) NOT NULL,
  `inp_date` datetime NOT NULL,
  `upd_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `cms_user`
--

INSERT INTO `cms_user` (`id`, `user_name`, `user_name_kana`, `address`, `phone`, `mail`, `company`, `passwd`, `inp_date`, `upd_date`) VALUES
(1, '金自成', 'キムジャソン', '大阪市中央区石町2-3-9', '0668096859', 'kimjason@pssys.jp', 'ポライトサポートシステム株式会社', 'kimjason', '2023-12-06 17:54:49', '2023-12-06 08:54:49'),
(3, '田中角栄', 'たなかかくえい', '新潟県柏崎市西山町坂田717 ', '0257482130', 'kakuei@souri.jp', '越山会', 'tanaka', '2023-12-26 15:35:34', '2023-12-26 06:35:34');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `cms_user`
--
ALTER TABLE `cms_user`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `cms_user`
--
ALTER TABLE `cms_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
