-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2024-01-16 07:41:50
-- サーバのバージョン： 10.4.28-MariaDB
-- PHP のバージョン: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `techfun`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `namecard`
--

CREATE TABLE `namecard` (
  `id` int(11) NOT NULL,
  `firstname_Ch` varchar(10) NOT NULL,
  `lastname_Ch` varchar(10) NOT NULL,
  `firstname_Kana` varchar(10) NOT NULL,
  `lastname_Kana` varchar(10) NOT NULL,
  `company` varchar(20) NOT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `mail` varchar(100) NOT NULL,
  `inp_date` datetime NOT NULL,
  `upd_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `namecard`
--

INSERT INTO `namecard` (`id`, `firstname_Ch`, `lastname_Ch`, `firstname_Kana`, `lastname_Kana`, `company`, `phone`, `mail`, `inp_date`, `upd_date`) VALUES
(11, '金', '自成', 'キム', 'ジャソン', '金自成', '09012226968', 'kimjason@gmail.jp', '2023-11-20 08:50:21', '2023-11-19 23:50:21'),
(12, '田中', '中田', 'タナカ', 'ナカタ', '田中中田', '0662645878', 'tanaka@nakata.com', '2023-11-20 08:57:57', '2023-11-19 23:57:57'),
(13, '田中', '田中', 'タナカ', 'タナカ', 'たなか', '01201230125', 'aa@bb.com', '2023-11-20 11:55:35', '2023-11-20 02:55:35'),
(14, '鈴木', '島田', 'スズキ', 'シマダ', '鈴木島田', '01002236541', 'suzuki@shimada.com', '2023-11-27 11:44:46', '2023-11-27 02:44:46'),
(15, '山本', '山', 'ヤマモト', 'ヤマ', 'ヤマモトヤマ', '0336965474', 'yamamotoyama@co.jp', '2023-11-27 19:09:33', '2023-11-27 10:09:33'),
(36, '田中', '角栄', 'タナカ', 'カクエイ', '越山会', '0424568754', 'kakuei@imataikou.jp', '2023-11-28 09:28:47', '2023-11-28 00:28:47'),
(37, '中曽根', '康弘', 'ナカソネ', 'ヤスヒロ', '遠目富士山', '05054789654', 'nakasone@daikun_i.jp', '2023-11-28 09:28:47', '2023-11-28 00:28:47'),
(38, '竹下', '登', 'タケシタ', 'ノボル', '経世会', '0808456786', 'noboru@keiseikai.com', '2023-11-28 09:28:47', '2023-11-28 00:28:47');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `namecard`
--
ALTER TABLE `namecard`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mail` (`mail`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `namecard`
--
ALTER TABLE `namecard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
